
<div class="padding-top"></div>
<!--===================== Footer Area ================= -->
<div class="foter-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6 ofsett-3">
                <p>&copy Tahmid Nishat | 2019<br>
                Email : tahmid.ni7@gmail.com</p>
                <div class="social-links">
                      <?= anchor("https://www.facebook.com/iamTahmid.ni7", '<i class="fab fa-facebook"></i>',['title'=>'Facebook', 'target'=>'_blank']); ?>
                      <?= anchor("https://github.com/tahmid-ni7", '<i class="fab fa-github"></i>',
                      ['title'=>'gitHub', 'target'=>'_blank']); ?>
                      <?= anchor("https://www.instagram.com/tahmid_ni7/", '<i class="fab fa-instagram"></i>', ['title'=>'Instagram', 'target'=>'_blank']); ?>
                </div>
            </div>
        </div>
    </div>
</div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script type="text/javascript" src="<?= base_url('tool/js/popper-1.12.9.min.js'); ?>"></script>
    <script type="text/javascript" src="<?= base_url('tool/js/bootstrap.min.js'); ?>"></script>
    <script type="text/javascript" src="<?= base_url('tool/js/all.js'); ?>"></script>
    <script type="text/javascript" src="<?= base_url('tool/js/owl.carousel.min.js'); ?>"></script>
    <script type="text/javascript" src="<?= base_url('tool/js/main.js'); ?>"></script>
</body>
</html>