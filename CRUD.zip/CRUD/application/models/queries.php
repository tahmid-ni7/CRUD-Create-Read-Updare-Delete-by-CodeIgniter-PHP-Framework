<?php

class queries extends CI_Model
{
	public $title;
	public $description;
	public $dateTime;

/*================== HERE "tdata" is database table name ==========*/

/*===================== Show all the data from database ===================*/
	public function getData()
	{
		$query = $this->db->get('tdata');
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
	}


/*====================== Insert the data ===============================*/
	public function addData($data)
	{
		return $this->db->insert('tdata', $data);
	}



/*===================== Get single row information ===================*/
	public function getsingleData($id)
	{
		$query = $this->db->get_where('tdata', array('id'=>$id));
		if($query->num_rows() > 0)
		{
			return $query->row();
		}
	}


/*===================== Update the Data ================================*/
	public function dataUpdate($data, $id)
	{
		return $query = $this->db->where('id', $id)->update('tdata', $data);
	}


/*==================== Delete the Data ===================================*/
	public function deleteData($id)
	{
		return $query = $this->db->delete('tdata', ['id'=>$id]);
	}
}

?>