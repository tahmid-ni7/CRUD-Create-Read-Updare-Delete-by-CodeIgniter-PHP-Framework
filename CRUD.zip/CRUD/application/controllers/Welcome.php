<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	

/*================= Load the Home Page & Get the Data =============*/
	public function index()
	{
		$this->load->model('queries');
		$data = $this->queries->getData();
		$this->load->view('home', ['data'=>$data]);
	}


/*================= Load the craete page ======================*/
	public function create()
	{
		$this->load->view('create');
	}


/*================== Get the data for update ====================*/
	public function update($id)
	{
		$this->load->model('queries');
		$data = $this->queries->getsingleData($id);
		$this->load->view('update', ['d'=>$data]);
	}


/*================= Data insert & Form validation ====================*/
	public function save()
	{
		$this->form_validation->set_rules('title', 'Title', 'required');
		$this->form_validation->set_rules('title', 'Title', 'trim|required|max_length[12]');
        $this->form_validation->set_rules('description', 'Description', 'required');
        if ($this->form_validation->run())
        {
			$data = $this->input->post();
			unset($data['submit']);
			$this->load->model('queries');
			if($this->queries->addData($data))
			{
				$this->session->set_flashdata('msg','Data saved successfully.');
			}
			else
			{
				$this->session->set_flashdata('msg','Faild to save the data');
			}
			return redirect('welcome');
        }
        else
        {
            $this->load->view('create');
        }
	}


/*========================== Update the data ==========================*/
	public function dataUpdate($id)
	{
		$this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        if ($this->form_validation->run())
        {
			$data = $this->input->post();
			unset($data['submit']);
			$this->load->model('queries');
			if($this->queries->dataUpdate($data, $id))
			{
				$this->session->set_flashdata('msg','Data updated successfully.');
			}
			else
			{
				$this->session->set_flashdata('msg','Faild to update the data');
			}
			return redirect('welcome');
        }
        else
        {
            $this->load->view('update');
        }
	}


/*==================== View the detail information ======================*/
	public function view($id)
	{
		$this->load->model('queries');
		$data = $this->queries->getsingleData($id);
		$this->load->view('view', ['d'=>$data]);
	}


/*===================== Delete the Data ==============================*/
	public function delete($id)
	{
		$this->load->model('queries');
		if($data = $this->queries->deleteData($id))
		{
			$this->session->set_flashdata('msg','Data deleted successfully.');
		}
		else
		{
			$this->session->set_flashdata('msg','Faild to delete the data');
		}
		return redirect('welcome');
	}
}
