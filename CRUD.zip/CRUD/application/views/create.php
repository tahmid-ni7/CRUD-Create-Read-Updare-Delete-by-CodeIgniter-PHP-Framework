<?php include_once('header.php'); ?>

<div class="content-area">
<div class="container">
<h3 class="title">Add Data to system</h3><hr>

<!-- ==================== Form start =========================-->
	<?= form_open('welcome/save');?>
  <div class="form-group row">
    <label for="title" class="col-sm-2 col-form-label">Title</label>
    <div class="col-sm-6">
      <?= form_input(['name'=>'title','placeholder'=>'Title...','value'=>set_value('title'),
      'class'=>'form-control']);?>
    </div>
    <div class="col-sm-4">
    	<?= form_error('title', '<div class="text-danger">','</div>'); ?>
    </div>
  </div>
  <div class="form-group row">
    <label for="Description" class="col-sm-2 col-form-label">Description</label>
    <div class="col-sm-6">
    <?= form_textarea(['name'=>'description','placeholder'=>'Description...',
    'value'=>set_value('description'),'class'=>'form-control']);?>
    </div>
    <div class="col-sm-4">
    	<?= form_error('description', '<div class="text-danger">','</div>'); ?>
    </div>
  </div>
     <div class="form-group row col-sm-10 offset-2">
     	<?= form_submit(['name'=>'submit','value'=>'Save', 'class'=>'btn btn-primary ms']); ?>
     	<?= form_reset(['name'=>'reset','value'=>'Reset', 'class'=>'btn btn-danger ms']); ?>
     </div>
	
	<?= form_close();?>

</div>
</div>

<?php include_once('footer.php'); ?>