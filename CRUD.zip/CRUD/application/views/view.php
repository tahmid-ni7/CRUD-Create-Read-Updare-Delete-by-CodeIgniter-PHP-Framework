<?php include_once('header.php'); ?>

<div class="content-area">
<div class="container">
<h3 class="title">Details info</h3>
<h4 class="title">Title: <?= htmlentities($d->title); ?></h4>
<div>Description: <?= htmlentities($d->description); ?></div>
<i>Date time: <?= htmlentities($d->dateTime); ?></i>

<br><br><?= anchor('welcome', 'Back >> Home', ['class'=>'btn btn-primary btn-sm']); ?>
</div>
</div>

<?php include_once('footer.php'); ?>