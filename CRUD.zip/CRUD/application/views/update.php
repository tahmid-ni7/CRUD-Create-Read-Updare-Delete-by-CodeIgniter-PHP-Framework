<?php include_once('header.php'); ?>

<div class="content-area">
<div class="container">
<h3 class="title">Update the data</h3><hr>

	<?= form_open("welcome/dataUpdate/{$d->id}");?>
  <div class="form-group row">
    <label for="title" class="col-sm-2 col-form-label">Title</label>
    <div class="col-sm-6">
      <?= form_input(['name'=>'title','placeholder'=>'Title...','value'=>set_value('title', $d->title),
      'class'=>'form-control']);?>
    </div>
    <div class="col-sm-4">
    	<?= form_error('title', '<div class="text-danger">','</div>'); ?>
    </div>
  </div>
  <div class="form-group row">
    <label for="Description" class="col-sm-2 col-form-label">Description</label>
    <div class="col-sm-6">
    <?= form_textarea(['name'=>'description','placeholder'=>'Description...',
    'value'=>set_value('description', $d->description),'class'=>'form-control']);?>
    </div>
    <div class="col-sm-4">
    	<?= form_error('description', '<div class="text-danger">','</div>'); ?>
    </div>
  </div>
     <div class="form-group row col-sm-10 offset-2">
     	<?= form_submit(['name'=>'submit','value'=>'Update', 'class'=>'btn btn-success ms']); ?>
     	<?= form_reset(['name'=>'reset','value'=>'Reset', 'class'=>'btn btn-danger ms']); ?>
     </div>
	
	<?= form_close();?>

</div>
</div>

<?php include_once('footer.php'); ?>