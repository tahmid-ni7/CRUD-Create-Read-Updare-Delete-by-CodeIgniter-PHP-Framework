
<!-- =====================================================
					WELCOME TO HOME PAGE
========================================================== -->

<?php include_once('header.php'); ?>

<!--===================== Content Area ================= -->
<div class="content-area">
	<div class="container">
	<h3 class="title">List of all data</h3><hr>
	<?php 
	if($msg = $this->session->flashdata('msg'))
	{
		print '<div class = "msg">';
		print $msg;
		print '</div>';
	}
	?>
	<?= anchor('welcome/create', "Add Data", ['class'=>'btn btn-primary']);?>
 <table class="table table-striped table-hover ">
  <thead>
    <tr>
      <th>ID</th>
      <th>Title</th>
      <th>Description</th>
      <th>Date Time</th>
      <th>Action</th>
    </tr>
  </thead>

  <tbody>
  	<?php if(count($data)):?>
  		<?php foreach($data as $d): ?>
    <tr>
      <td><?= htmlentities($d->id); ?></td>
      <td><?= substr(htmlentities($d->title), 0,12); ?></td>
      <td><?= substr(htmlentities($d->description),0,20); ?>....<?= anchor("welcome/view/{$d->id}","More")?></td>
      <td><?= htmlentities($d->dateTime); ?></td>
      <td>
      	<?= anchor("welcome/view/{$d->id}", "<i class='fas fa-eye'></i>", ['class'=>'btn btn-primary btn-sm', 'title'=>'View']);?>
      	<?= anchor("welcome/update/{$d->id}", "<i class='fa fa-wrench'></i>", ['class'=>'btn btn-success btn-sm','title'=>'Update']);?>
      	<?= anchor("welcome/delete/{$d->id}", "<i class='fas fa-trash'></i>", ['class'=>'btn btn-danger btn-sm', 'title'=>'Delete']);?>
      </td>
    </tr>
		<?php endforeach; ?>
    <?php else: ?>
    	<tr>
    		<td>No records found!</td>
    	</tr>
    <?php endif; ?>
  </tbody>

</table> 
</div>
</div>

<?php include_once('footer.php'); ?>