(function ($) {
	'use strict';

	jQuery(document).ready(function () {

		$('.featured-projects').owlCarousel({
			items: 1,
			nav: false,
			dots: true,
			loop: true
		});

	});


})(jQuery);